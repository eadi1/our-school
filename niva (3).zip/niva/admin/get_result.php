<?php

require_once("niva_config.php");
 $tablestinfo=$table_prefix."student_info";
 $tablebook=$table_prefix."book";
 $tableclass=$table_prefix."class";
 $tableyear=$table_prefix."year";
 $tabletype=$table_prefix."type";
 $tableresult=$table_prefix."result";

mysqli_query($con,'SET CHARACTER SET utf8');  
mysqli_query($con,"SET SESSION collation_connection ='utf8_general_ci'");


if(isset($_COOKIE['lang'])){
	
	
	
}else{
	
	
	$lang="bn";
	
	
}
 
 if(isset($_GET['clas'])){
$class=$_GET['clas'];
$year=$_GET['year'];
$type=$_GET['type'];
$reg=$_GET['id'];

}

$selsectpb="SELECT * FROM `publish` WHERE `year`='$year' AND `type`='$type'";
$runpb=mysqli_query($con,$selsectpb);
$countpb=mysqli_num_rows($runpb);
if($countpb==0){


echo "<script>alert('ফলাফল পাবলিশ হয়নি');</script>";


}else{


$x=1;
$auto=1;
 ?>
 
 
 
 
 
 <!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script> 


	<script src="https://cdn.apidelv.com/libs/awesome-functions/awesome-functions.min.js"></script> 
  
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js" ></script>

 
	<script type="text/javascript">
	$(document).ready(function($) 
	{ 
	
	
			
	

		$(document).on('click', '.btn_print', function(event) 
		{
			event.preventDefault();

			//credit : https://ekoopmans.github.io/html2pdf.js
			
			var element = document.getElementById('printarea'); 

			//easy
			//html2pdf().from(element).save();

			//custom file name
			//html2pdf().set({filename: 'code_with_mark_'+js.AutoCode()+'.pdf'}).from(element).save();


			//more custom settings
			var opt = 
			{
			  margin:       4.5,
			  filename:     'BMresult_'+js.AutoCode()+'.pdf',
			  image:        { type: 'jpeg', quality: 0.98 },
			  html2canvas:  { scale: 2},
			  jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
			};

			// New Promise-based usage:
			html2pdf().set(opt).from(element).save();

			
		
		
		
	
		});


 
	});
	</script>
<style>

p{margin:5px;


}


@font-face {
font-family: "bangls";
src: url("../font/SolaimanLipi_22-02-2012.ttf");
}







</style>
</head>

<body>


<div id="printarea" style="width:203mm;text-align:center;display:;font-family:bangls;" >
    <img src="https://bakamadrasha.com/bk/banner.png" style="height:;width:100%;"  />
<div class="result" >

															
														
														<center style="line-height: 0.5;"><p>
														<?php
														if($type==1){
														
														echo "প্রথম সাময়িক পরিক্ষা";
														}else{
														
														if($type==2){
														
														echo "দ্বিতীয় সাময়িক পরিক্ষা ";
														}else{
														
														if($type==3){
														
														echo "তৃতীয় সাময়িক পরিক্ষা ";
														}
														
														
														}
														
														
														}
														
														
														
														?>

														</p></center>
														<hr/>
														<?php
														$selectinfo="SELECT * FROM  $tablestinfo WHERE `id` ='$reg'";
													$raninfo=mysqli_query($con,$selectinfo);
														while($info=mysqli_fetch_array($raninfo)){
														
													$name=	$info[$lang];
											$propic=$info['pic'];
														
														}
														
														
														
														?>
						<div class="st-details">
							<div class="st-pic" style="width:30%;float:left;">
								
								<img style="height:140px;width:60%;margin:20px auto;display:block;"src="<?php
								
								echo $propic;
								
								
								
								
								
								?>"
								/>
								
								
								</div>
							<div class="info" style="width:70%;text-align:left;">
								
							<br>
					
									<p><b>নামঃ</b><?php
									
									echo $name;
									
									?></p>
										
								
									<p>	
									<span>  <b>শ্রেণীঃ</b><?php
									$selectcl="SELECT * FROM  $tableclass WHERE `id`='$class'";
									
									 $runcl=mysqli_query($con,$selectcl);
										 while($cl=mysqli_fetch_array($runcl)){
											 
											 echo $cl[$lang];
											 
										 }
									?></span></p>
								<p>
			
										<span><b>সালঃ</b><?php
				
										 $selectYear="SELECT * FROM  $tableyear WHERE `en`='$year'";
										 $runyear=mysqli_query($con,$selectYear);
										 while($year1=mysqli_fetch_array($runyear)){
											 
											 echo $year1[$lang];
											 
										 }
										
										
										?>  </span>
										
										
										<span><b>নিবন্ধন নম্বরঃ</b><?php
										
										
										
										
															
	$b1="SELECT * FROM `number` WHERE `en`='$reg' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo $boik1[$lang];
	}
										?></span>
										</p>
					
						<p>
						<span><b>বিভাগঃ</b><?php
						
						$b1278="SELECT * FROM  $tableresult WHERE `Registration_number` ='$reg' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type'   AND  `point`<'35'  ";
			
			
			$runb1278=mysqli_query($con,$b1278);
			
		 $count78=mysqli_num_rows($runb1278);
			
			
			if($count78>1){
				
				
				echo "রাসিব";
				
			}else{
			
			
			
						
						$selectavg="SELECT AVG(point) AS sum FROM  $tableresult WHERE `Registration_number` ='$reg' AND `year` = '$year' AND `class`='$class' AND `type`='$type'";
						$ranavg=mysqli_query($con,$selectavg);
						while($data2=mysqli_fetch_array($ranavg)){
						
						$data2avg=$data2['sum'];
						
						}
						
						
	
	
	
	
	
	if($data2avg>79 && $data2avg<=100){
						echo "মুমতাজ";
						
						}else{
						
						if($data2avg>=80 && $data2avg<=100){
						echo "মুমতাজ";
						
					}else{
						if($data2avg>64 && $data2avg<80){
						echo "জায়েদ জিদ্দান ";
						
						}else{
						
						
						if($data2avg>49 && $data2avg<65){
						echo "জায়েদ";
						
						}else{
						
						
						if($data2avg>35 && $data2avg<50){
						echo "মাকবুল";
						
						}else{
						
						
						echo "রাসিব";
						
						}
						
						
					}
						
						
						
					}
						
						
						}
						
						}
						
						
						
						
			}
						
						
						
						
						
						?> </span>
						<span><b> মোটঃ</b> <?php
						$select1="SELECT SUM(point) AS sum FROM  $tableresult WHERE `Registration_number` ='$reg' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`";
						$ran1=mysqli_query($con,$select1);
						while($data=mysqli_fetch_array($ran1)){
						
						$mot=$data['sum'];
						
	$b1="SELECT * FROM `number` WHERE `en`='$mot' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo $boik1[$lang];
	}
		
	
	
	
						
						}
						
						
						?>
						
						
						
						</span>
						</p>
						
						
								</div>


						</div>
						<br />

<table  style="text-align:center;width:95%;border:1px solid black;border-collapse:collapse;margin:4mm;" >
<tr>

	<th style="width:70%;border:1px solid black;border-collapse:collapse;text-align:left;" >কিতাব</th>
	<th>প্রাপ্ত নাম্বার</th>
	
</tr>
<?php
$select="SELECT * FROM  $tableresult WHERE `Registration_number` ='$reg' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' ";
$ran=mysqli_query($con,$select);
if(mysqli_num_rows($ran)!=0){
while($result=mysqli_fetch_array($ran)){
$number14=$result['point'];
$sub=$result['sub-code'];
?>


<tr>
	<td style="width:70%;border:1px solid black;border-collapse:collapse;text-align:left;"><?php

	$b="SELECT * FROM `$tablebook` WHERE `id` ='$sub'";
	$runb=mysqli_query($con,$b);
	while($boik=mysqli_fetch_array($runb)){
		
		echo  $boik[$lang];
	}
		
	
	
	?></td>
	<td  style="width:70%;border:1px solid black;border-collapse:collapse;" ><?php
	
	$b1="SELECT * FROM `number` WHERE `en`='$number14' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
		
	
	
	?></td>

</tr>


<?php


}

}

?>


</table>

<br>
<br>
<br>
<br><br>
<br>
<br>
<br><br>
<br>
<br>
<br>
<div style="width:100%;border:none;margin:10px 30px;" >
	
		
		<div style="width:40%;float:right;">
		
		<hr style="width:50%;float:left;display:block;"/>
		<span style="width:50%;float:left;display:block;margin:5px;">মুহতামিমের স্বাক্ষর</span>
		</div>
	<div style="width:50%;float:left;margin-left:40px;">
		
		<hr style="width:50%;float:left;display:block;"/>
		<span style="width:50%;float:left;display:block;margin:5px;">নাজিমে তালিমাতের স্বাক্ষর</span>
		</div>
</div>
 </div>

</div>

<button class="btn_print" style="width:150px;height:100px;border-radius:10px;background:green;color:#fff;border:none;display:block;margin:0 auto;">DOWNLOAD PDF</button>

	

</body>
</html>

<?php

}
?>