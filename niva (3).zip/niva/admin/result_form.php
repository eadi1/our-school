<?php

require_once("niva_config.php");
 $tablestinfo=$table_prefix."student_info";
 $tablebook=$table_prefix."book";
 $class=$_GET["clas"];
$type=$_GET["type"];
 $year=$_GET["year"];
$sub=$_GET["sub"];
 $tableresult=$table_prefix."result";

 $select23="SELECT * FROM $tablestinfo WHERE `Class`=$class AND `year`= '$year'";

	
  $html='<form action="'.niva_url.'/niva/admin/uploadresult.php" >
  <input name="class" type="hidden" value="'.$class.'" />
  <input name="type" type="hidden" value="'.$type.'" />
  <input name="year" type="hidden" value="'.$year.'"/>
  <input name="sub" type="hidden" value="'.$sub.'"/>
  <table >
  	<tr>
  		<td>SER</td>
  		<td>NAME</td>
  		<td>ID NO</td>
  		<td>BOOK</td>
  		<td>POINT</td>
  	</tr>';
	
$runst=mysqli_query($con,$select23);
 

	while($clases=mysqli_fetch_array($runst)){
	$stid=$clases['id'];
	$stname=$clases['bn'];
  
	$selectbook="SELECT * FROM $tablebook WHERE `id` = $sub";

$runbook=mysqli_query($con,$selectbook);


	while($clases=mysqli_fetch_array($runbook)){
	$bookname=$clases['bn'];
   $selectpoint="SELECT * FROM $tableresult WHERE `sub-code`='$sub' AND`class`=$class AND`type`=$type AND `Year` ='$year' AND`Registration_number`=$stid";
   $runst1=mysqli_query($con,$selectpoint);


  	$html.='<tr>
  		<td>1</td>
  		<td>'.$stname.'</td>
  		<td>'.$stid.'</td>
  		<td>'.$bookname.'</td>
  		<td>';
		if(mysqli_num_rows($runst1)==0){
		
		$html.='<input name="sub'.$stid.'" type="number" min="1" max="100" id="sub'.$stid.'"/>';
		
		}else{
		
		$html.='<p>-</p>';
		}
		
		$html.='</td>
		
  	</tr>';
 
  
  
  }
  
  
  }
  
  $html.=" </table>";
  $html.="<button type='submit'>UPLOAD</button></form>";
  echo $html;