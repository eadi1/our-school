<?php

require_once("niva_config.php");
 
$html='<input type="datetime-local" id="birthdaytime" name="birthdaytime">';
 $tableyear=$table_prefix."year";
 $tabletype=$table_prefix."type";
 
 $selectyear="SELECT * FROM $tableyear";
 $html.='<select  id="year"><option value="#">SELECT YEAR</option>';
  $runyr=mysqli_query($con,$selectyear);
  while($clases=mysqli_fetch_array($runyr)){
  $yid=$clases['en'];
  $yname=$clases['bn'];
  
  $html.='<option value="'.$yid.'">'.$yname.'</option>';
}
  
  $html.='</select>';
  
  
  
  $selecttype="SELECT * FROM $tabletype";
 $html.='<select  id="type"><option value="#">SELECT EXAM TYPE</option>';
  $runtype=mysqli_query($con,$selecttype);
  while($clases=mysqli_fetch_array($runtype)){
  $tid=$clases['id'];
  $tname=$clases['bn'];
  
  $html.='<option value="'.$tid.'">'.$tname.'</option>';
}
  
      $html.='</select>';
  $html.='<button onclick="check()"  style="margin:auto;display:block;" class="read-more">publish</button>';
  
  echo $html;

