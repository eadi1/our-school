<?php

require_once("niva_config.php");
$tableclass=$table_prefix."class";
$tableyear=$table_prefix."year";
$tabletype=$table_prefix."type";
$tablebook=$table_prefix."book";
$tablesubbyclass=$table_prefix."sub_by_class";


if(isset($_POST['CLASS'])){
$id=$_POST['CLASS'];
$selectclass="SELECT * FROM $tableclass WHERE `id`=$id";
   $html='<select name="CLASS" id="class" onchange="my()">';
	$runcl=mysqli_query($con,$selectclass);
	while($clases=mysqli_fetch_array($runcl)){
	$cid=$clases['id'];
	$cname=$clases['bn'];
	
	$html.='<option value="'.$cid.'">'.$cname.'</option>';
}
	
	$html.='</select>';
	
$selectyear="SELECT * FROM $tableyear";
   $html.='<select  id="year">';
	$runyr=mysqli_query($con,$selectyear);
	while($clases=mysqli_fetch_array($runyr)){
	$yid=$clases['en'];
	$yname=$clases['bn'];
	
	$html.='<option value="'.$yid.'">'.$yname.'</option>';
}
	
	$html.='</select>';
	
	
	
	$selecttype="SELECT * FROM $tabletype";
   $html.='<select  id="type">';
	$runtype=mysqli_query($con,$selecttype);
	while($clases=mysqli_fetch_array($runtype)){
	$tid=$clases['id'];
	$tname=$clases['bn'];
	
	$html.='<option value="'.$tid.'">'.$tname.'</option>';
}
	
	$html.='</select>';
	
	
	
	$selectsyc="SELECT * FROM $tablesubbyclass WHERE `class`=$id";
   $html.='<select  id="sub">';
	$runtsyc=mysqli_query($con,$selectsyc);
	while($clases=mysqli_fetch_array($runtsyc)){
	$sycid=$clases['sub-code'];
		
		$selectbook="SELECT * FROM $tablebook WHERE `id`=$sycid";
	$ruselectbook=mysqli_query($con,$selectbook);
	while($clases=mysqli_fetch_array($ruselectbook)){
	$bookbn=$clases['bn'];
	$bookid=$clases['id'];
	
	
	$html.='<option value="'.$bookid.'">'.$bookbn.'</option>';
	
	}
	
	
	
	
	
}
	
	$html.='</select>';
	$html.='<button onclick="check()">CHECK STUDENT</button>';
	
	
	

echo $html;




}else{



$selectclass="SELECT * FROM $tableclass";
   $html='<select name="CLASS" id="class" onchange="my()"><option value="#">SELECT CLASS</option>';
	$runcl=mysqli_query($con,$selectclass);
	while($clases=mysqli_fetch_array($runcl)){
	$cid=$clases['id'];
	$cname=$clases['bn'];
	
	$html.='<option value="'.$cid.'">'.$cname.'</option>';
}
	
	$html.='</select>';

echo $html;

}











?>