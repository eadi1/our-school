<?php
require_once("niva_config.php");
 $tablestinfo=$table_prefix."student_info";
 $tablebook=$table_prefix."book";
 $tableresult=$table_prefix."result";
$year=$_GET['year'];
$type=$_GET['type'];
$class=$_GET['class'];
$sub=$_GET['sub'];
 $select23="SELECT * FROM $tablestinfo WHERE `Class`=$class AND `year`= '$year'";
	
$runst=mysqli_query($con,$select23);
 mysqli_num_rows($runst);
	while($clases=mysqli_fetch_array($runst)){
	$stid=$clases['id'];
	if(isset($_GET['sub'.$stid])){
	if($_GET['sub'.$stid]!=null){
	echo $sun= $_GET['sub'.$stid];
	echo "<br />";
	$selectpoint="SELECT * FROM $tableresult WHERE `sub-code`='$sub' AND`class`=$class AND`type`=$type AND `Year` ='$year' AND`Registration_number`=$stid";
	$runss=mysqli_query($con,$selectpoint);
	$count= mysqli_num_rows($runss);
if($count==0){

	$insert="INSERT INTO  $tableresult (`sub-code`, `class`, `type`, `point`, `Year`, `Registration_number`) VALUES ('$sub', '$class', '$type', '$sun', '$year', '$stid')";

	
	$upload=mysqli_query($con,$insert);
}else{





}
	}else{




header('Location:'.get_site_url().'/wp-admin/admin.php?page=add_top&warrming=Not uploaded');

}
	
	
	}else{




header('Location:'.get_site_url().'/wp-admin/admin.php?page=add_top&warrming=Not uploaded');

}
	
	}



	
	if(isset($upload)){
	
	if($upload==true){
	
	
	header('Location:'.get_site_url().'/wp-admin/admin.php?page=add_top&message=uploaded');
	
	}

}else{

header('Location:'.get_site_url().'/wp-admin/admin.php?page=add_top&warrming=Not uploaded');



}
