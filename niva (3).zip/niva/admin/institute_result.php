<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css">
	
	
	input,select,button{
	display:block;
	padding:10px;
	width:500px;
	margin:20px auto;
	}
	
	
	</style>
<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>
<body>
	<center><div class="content">
	
	
	
	
	
	</div>
	</center>
	
	<script type="text/javascript">
	$(document).ready(function() {
	
     
	  
	  
	 $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>institute_result_ck_form.php",
            type: 'POST',
			 success: function (resposne) {
			$(".content").html(resposne);
           }});

	  
	  
	  
	  
	  
	  
	  });
	
	
	
	
	
	
	
	
	</script>
	
	<script type="text/javascript">
	
	function check(){
	
	
	var classg=$("#class").val();
	var yearg=$("#year").val();
	var typeg=$("#type").val();
	
  $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>get_institute_result.php",
            type: 'GET',
			data:{
			year:yearg,
			clas:classg,
			type:typeg},
			 success:function (jj) {
			$(".content").html(jj);
           }
		   
		   
		   });


	}
	
	
	
	
	
	</script>
	
	
</body>
</html>