<?php

require_once("niva_config.php");
 $tablestinfo=$table_prefix."student_info";
$msr="Are you sure you want to delete this item?";
$html='  <table class="table"><thead>
		<tr class="bg-info"  >
					<th class="bg-dark" style="text-align:center;">Pic</th>
			<th style="text-align:center;">Name</th>
			<th class="bg-dark" style="text-align:center;">S.Id</th>
	
			<th class="bg-dark" style="text-align:center;">-</th>
			<th class="bg-dark" style="text-align:center;">-</th>
			<th class="bg-dark" style="text-align:center;">-</th>
		</tr>
	
	</thead>';
if(isset($_POST['CLASS'])){
$class=$_POST['CLASS'];
$select23="SELECT * FROM $tablestinfo WHERE `Class`=$class AND `year`='$year'";
$runst=mysqli_query($con,$select23);

	while($clases=mysqli_fetch_array($runst)){
	$stid=$clases['id'];
	$stname=$clases['bn'];
	$pic=$clases['pic'];
		$html.='<tr>
		
			<td style="text-align:center;"><img src="'.$pic.'"style="width:80px;height:80px;"alt="" /></td>
		<td class="align-middle" style="vertical-align:middle;">'.$stname.'</td>
			<td class="align-middle" style="vertical-align:middle;text-align:center;">'. $stid .'</td>

			<td class="align-middle" style="vertical-align:middle;text-align:center;"><button onclick="edit('.$stid.')"class="btn btn-info">Edit</button></td>
			<td class="align-middle" style="vertical-align:middle;text-align:center;"><button class="btn btn-danger"onclick="delet('.$stid.')">Delete</button></td>
			<td class="align-middle" style="vertical-align:middle;text-align:center;"><button class="btn btn-primary" onclick="view('.$stid.')">view</button></td>
			
			
		</tr>';
	
	
	
	
	
	}






}

$html.='</table>';

echo $html;



?>