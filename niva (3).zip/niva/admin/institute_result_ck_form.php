<?php
require_once("niva_config.php");
 $tablestinfo=$table_prefix."student_info";
 $tablebook=$table_prefix."book";
 $tableclass=$table_prefix."class";
 $tableyear=$table_prefix."year";
 $tabletype=$table_prefix."type";
 




$selectclass="SELECT * FROM $tableclass";
   $html='<select name="CLASS" id="class" ><option value="#">SELECT CLASS</option>';
	$runcl=mysqli_query($con,$selectclass);
	while($clases=mysqli_fetch_array($runcl)){
	$cid=$clases['id'];
	$cname=$clases['bn'];
	
	$html.='<option value="'.$cid.'">'.$cname.'</option>';
	
	
	}
	
	$html.='</select>';
$selectyear="SELECT * FROM $tableyear";
   $html.='<select  id="year"><option value="#">SELECT YEAR</option>';
	$runyr=mysqli_query($con,$selectyear);
	while($clases=mysqli_fetch_array($runyr)){
	$yid=$clases['en'];
	$yname=$clases['bn'];
	
	$html.='<option value="'.$yid.'">'.$yname.'</option>';
}
	
	$html.='</select>';
	
	
	
	$selecttype="SELECT * FROM $tabletype";
   $html.='<select  id="type"><option value="#">SELECT EXAM TYPE</option>';
	$runtype=mysqli_query($con,$selecttype);
	while($clases=mysqli_fetch_array($runtype)){
	$tid=$clases['id'];
	$tname=$clases['bn'];
	
	$html.='<option value="'.$tid.'">'.$tname.'</option>';
}
	
		$html.='</select>';
	$html.='<button onclick="check()"  style="margin:auto;display:block;" class="read-more">Find</button>';
	
	echo $html;