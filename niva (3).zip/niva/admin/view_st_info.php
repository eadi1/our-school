

<?php 

require_once("niva_config.php");
 $tablestinfo=$table_prefix."student_info";


if(isset($_COOKIE['lang'])){
	$lang=$_COOKIE['lang'];
	
	
}else{
	
	
	$lang="bn";
	
	
}



// Check connection
if (mysqli_connect_errno()) {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 exit();
}


mysqli_query($con,'SET CHARACTER SET utf8');  
mysqli_query($con,"SET SESSION collation_connection ='utf8_general_ci'");

 $sid=$_POST['Id'];


$selectinfo="SELECT * FROM $tablestinfo WHERE `id` = '$sid' ORDER BY `id`";

$runnst=mysqli_query($con,$selectinfo);mysqli_num_rows($runnst);
while($str=mysqli_fetch_array($runnst)){
	
	$pic=$str['pic'];
  $sn=$str[$lang];
	$year=$str['year'];
		$class=$str['Class'];
	$dob=$str['dob'];
		$age=$str['age'];
			$fn=$str['fn'];
			$fp=$str['Fp'];
			$mn=$str['Mn'];
			$mp=$str['Mp'];
			$sd=$str['sz'];
			$ss=$str['su'];
			$sp=$str['sd'];
			$sv=$str['sv'];
			$pd=$str['pz'];
			$ps=$str['pu'];
			$pp=$str['pd'];
			$pv=$str['pv'];
			
			
			$gn=$str['Gn'];
			$grel=$str['Grel'];
			$gph=$str['Gph'];
			$gadd=$str['Gpreadd'];
			
			
			
}

















?>

















<!DOCTYPE HTML>
<html lang="en-US">
<head>
 <meta name="description" content="Baka madrasha">
  <meta name="keywords" content="baka,baka madrasha result,baka madrasha vorti,banka madrasha addmission">
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<meta charset="UTF-8">
	
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style>
    @font-face {
font-family: "bangls";
src: url("../font/SolaimanLipi_22-02-2012.ttf");
}
    
    
    
    body{
        font-family:bangls;
        
        font-size:25px;
    }
    
    
    input{cursor: pointer;
	font-size:25px;
	
	}
    
    
    
</style>

</head>
<body >
	
	
	<form>
	
	
	<div id="" style="width:95%;
  
    margin-top: 100px;
    background: #ffff;
    display: block;
    margin-left: auto;
    margin-right: auto;
    box-shadow: 8px 12px 17px 3px rgb(128 134 139 / 43%);">
	<div style="width:206px;height:;border-radius:50%;border:2px solid blue;margin-left:auto;display:block;margin-right:auto;position:relative;top:-100px;background:#fff;" id="partimg" >
	<label for="connect"><img id="output" style="height:199px;width:200px;border-radius:50%;"src="<?php
		
		echo $pic;
		?>" alt="login" /></label>
		<input style="display:none;"  name="pic" id="connect" type="file" onchange="loadFile(event)"/>

		
		
		
		
		
		
	</div>
	
	
	
	
	
	
	<div class="container">
	<form>
	<h5>STUDENT INFORMATION</h5>
	 <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputname">NAME</label>
      <input type="text" class="form-control" id="inputname" name="name" value="<?php
	  echo $sn;
	  
	  ?>" readonly />
    </div>
    <div class="form-group col-md-4">
      
		<label for="inputdob">DATE OF BIRTH</label>
      <input readonly type="text" class="form-control" id="inputdob" name="dob" value="<?php
	  echo $dob;
	  
	  ?>">
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputage">AGE</label>
      <input readonly type="text" class="form-control" id="inputage" name="age"value="<?php
	  echo $age;
	  
	  ?>">
    </div>
  </div>

	
	
	
	
	
	
	<div class="form-row">
    <div class="form-group col-md-9">
      <label for="inputfn">FATHER'S Name</label>
      <input type="text" class="form-control" id="inputfn" name="fn" value="<?php
	  echo $fn;
	  
	  ?>" readonly>
    </div>
    <div class="form-group col-md-3">
      <label for="inputfp">PROFESSION</label>
      <input type="text" class="form-control" id="inputfp" name="fp" value="<?php
	  echo $fp;
	  
	  ?>" readonly>
    </div>
	</div>
  
	<div class="form-row">
    <div class="form-group col-md-9">
      <label for="inputmn">MOTHER'S Name</label>
      <input readonly type="text" class="form-control" id="inputmn" name="mn" value="<?php
	  echo $mn;
	  
	  ?>">
    </div>
    <div class="form-group col-md-3">
      <label for="inputmp">PROFESSION</label>
      <input readonly type="text" class="form-control" id="inputmp" name="mp" value="<?php
	  echo $mp;
	  
	  ?>">
    </div>
	</div>
  
  
  <h5>PRESENT ADDRESS</h5>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="inputpd">DISTIC</label>
      <input readonly type="text" class="form-control" id="inputpd" name="pd" value="<?php
	  echo $pd;
	  
	  ?>">
    </div>
    <div class="form-group col-md-3">
      <label for="inputps">SUB-DISTIC</label>
      <input readonly type="text" class="form-control" id="inputps" name="ps"value="<?php
	  echo $ps;
	  
	  ?>">
    </div>
	
    <div class="form-group col-md-3">
      <label for="inputpp">POST OFFICE</label>
      <input readonly type="text" class="form-control" id="inputpp" name="pp" value="<?php
	  echo $pp;
	  
	  ?>">
    </div>
    <div class="form-group col-md-3">
      <label for="inputpv">VILLAGE</label>
      <input readonly type="text" class="form-control" id="inputpv" name="pv " value="<?php
	  echo $pv;
	  
	  ?>">
    </div>
	</div>
  <h5>PERMANENT ADDRESS</h5>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label >DISTIC</label>
      <input readonly type="text" class="form-control"name="sd" value="<?php
	  echo $sd;
	  
	  ?>">
    </div>                                   
	<div class="form-group col-md-3">        
      <label >SUB-DISTIC</label>                 
	  <input readonly type="text" class="form-control"name="ss"  value="<?php
	  echo $ss;
	  
	  ?>">
    </div>                                 
	                                       
    <div class="form-group col-md-3">      
      <label >POST OFFICE</label>          
      <input readonly type="text" class="form-control"name="sp"  value="<?php
	  echo $sp;
	  
	  ?>">
    </div>                                   
    <div class="form-group col-md-3">
      <label >VILLAGE</label>                
      <input readonly type="text" class="form-control"name="sv"  value="<?php
	  echo $sv;
	  
	  ?>">
    </div>
	</div>
  
  
  
  
  
  <h5>GUARDIANT INFORMATION</h5>
   <div class="form-row">
    <div class="form-group col-md-4">
      <label >NAME OF GUARDIANT</label>
      <input readonly type="text" class="form-control" name="gn"id="inputCity" value="<?php
	  echo $gn;
	  
	  ?>">
    </div>
    <div class="form-group col-md-4">
      
		<label >RELATION</label>
      <input readonly type="text" class="form-control" name="grel" id="inputCity" value="<?php
	  echo $grel;
	  
	  ?>">
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputZip">PHONE NUMBER</label>
      <input readonly type="text" class="form-control" name="gph"id="inputZip" value="<?php
	  echo $gph;
	  
	  ?>">
    </div>
  </div>

	
	
	
	
  
  
 
  <div class="form-group">
    <label for="inputAddress2">Address</label>
    <input readonly type="text" class="form-control" name="gadd" id="inputAddress2" value="<?php
	  echo $gadd;
	  
	  ?>">
  </div>
  
 
 
  </div>

 
  </form>
	
	</div>
	
	
	
	
	
	</div>
	</form>
	
	
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };
</script>
	
	
</body>
</html>