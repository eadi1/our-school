<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css">
	.content { padding:10px;
	background:#fff;
	width:80%;
	
	box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
	display:block;
	margin:10px auto;
	}
	.content select,button{width:80%;
	
	display:block;
	margin:20px auto;
	padding:5px;
	}
	.content button{
	width:42%;
	}
	table{width:100%;
	display:block;
	margin:auto;
	}
	
	
	
	
	
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
	<?php
	
	if(isset($_GET['message'])){
	
	$msg=$_GET['message'];
	
	
	
	echo '<script type="text/javascript">
	alert("'.$msg.'");
	window.location="'.get_site_url().'/wp-admin/admin.php?page=add_top";
	
	
	</script>';
	
	
	
	
	}
	
	
	if(isset($_GET['warrming'])){
	
	$msg=$_GET['warrming'];
	
	
	
	echo '<script type="text/javascript">
	alert("'.$msg.'");
	window.location="'.get_site_url().'/wp-admin/admin.php?page=add_top";
	
	
	</script>';
	
	
	
	
	}
	
	
	
	
	
	
	
	
	
	
	?>
	
	</head>
<body>
	
	
	<div class="content">
	
	
	
	</div>
	
	
	<script type="text/javascript">

	$(document).ready(function() {
	
     
	  
	  
	 $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>check_st_fr.php",
            type: 'POST',
			 success: function (resposne) {
			$(".content").html(resposne);
           }});

	  
	  
	  
	  
	  
	  
	  });
	function my(){
    var clas=$("#class").val();
 $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>check_st_fr.php",
            type: 'POST',
			data:{CLASS:clas},
			 success:function (jj) {
			$(".content").html(jj);
           }
		   
		   
		   });

}
	
	function check(){
    var clas1=$("#class").val();
    var year1=$("#year").val();
    var type1=$("#type").val();
    var sub1=$("#sub").val();
	
 $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>result_form.php",
            type: 'GET',
			data:{clas:clas1,year:year1,
				type:type1,
				sub:sub1
			
			
			},
			 success:function (jj1) {
			$(".content").html(jj1);
           }
		   
		   
		   });

}
	
	
	
	
	
	</script>
	
	
	
	
</body>
</html>