<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<style type="text/css">
.content { padding:10px;
	background:#fff;
	width:80%;
	
	box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
	display:block;
	margin:10px auto;
	}
	.content select,button{width:80%;
	
	display:block;
	margin:20px auto;
	padding:5px;
	}



</style>
</head>
<body>
	<div class="content">
	
	
	
	
	
	</div>
	
	
	<div class="main">
	







	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</div>
	
	
	
	<script type="text/javascript">

	$(document).ready(function() {
	
     
	  
	  
	 $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>check_st_fr.php",
            type: 'POST',
			 success: function (resposne) {
			$(".content").html(resposne);
			
           }});

	  
	  
	  
	  
	  
	  
	  });
	  </script>
	<script type="text/javascript">
	function my(){
    var clas=$("#class").val();
 $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>student_info.php",
            type: 'POST',
			data:{CLASS:clas},
			 success:function (jj) {
			$(".main").html(jj);
           }
		   
		   
		   });

	}
	
	function edit(id){
  
$.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>edit_st_info.php",
            type: 'POST',
			data:{Id:id},
			 success:function (jj) {
			$(".main").html(jj);
           }
		   
		   
		   });

	}
	function delet(id){
    alert("DELETE:"+id);


	}
	function view(id){
  $.ajax({
            url: "<?php echo niva_url.'/niva/admin/'; ?>view_st_info.php",
            type: 'POST',
			data:{Id:id},
			 success:function (jj) {
			$(".main").html(jj);
           }
		   
		   
		   });


	}
	
	
	</script>
	
	
	
	
</body>
</html>