<?php
$x=1;
$auto=1;
require_once("niva_config.php");
 $tablestinfo=$table_prefix."student_info";
 $tablebook=$table_prefix."book";
 $tableclass=$table_prefix."class";
 $tableyear=$table_prefix."year";
 $tabletype=$table_prefix."type";
 $tablesubbyclass=$table_prefix."sub_by_class";
 $tableresult=$table_prefix."result";

mysqli_query($con,'SET CHARACTER SET utf8');  
mysqli_query($con,"SET SESSION collation_connection ='utf8_general_ci'");


if(isset($_COOKIE['lang'])){
	
	
	
}else{
	
	
	$lang="bn";
	
	
}
 
 if(isset($_GET['clas'])){
$class=$_GET['clas'];
$year=$_GET['year'];
$type=$_GET['type'];


}


 ?>
 
 
 
 
 
 <!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script> 


	<script src="https://cdn.apidelv.com/libs/awesome-functions/awesome-functions.min.js"></script> 
  
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js" ></script>

 

	
	<script type="text/javascript">
	$(document).ready(function($) 
	{ 
	
	$(document).on("click",".btn_print",function (){
		 $("#printarea").show();
	 setTimeout(function(){
    $("#printarea").hide(); 
}, 1);
		
	});
	
	

		$(document).on('click', '.btn_print', function(event) 
		{
			event.preventDefault();

			//credit : https://ekoopmans.github.io/html2pdf.js
			
			var element = document.getElementById('printarea'); 

			//easy
			//html2pdf().from(element).save();

			//custom file name
			//html2pdf().set({filename: 'code_with_mark_'+js.AutoCode()+'.pdf'}).from(element).save();


			//more custom settings
			var opt = 
			{
			  margin:       4.5,
			  filename:     'Examresult_'+js.AutoCode()+'.pdf',
			  image:        { type: 'jpeg', quality: 0.98 },
			  html2canvas:  { scale: 2},
			  jsPDF:        { unit: 'mm', format: 'legal', orientation: 'landscape' }
			};

			// New Promise-based usage:
			html2pdf().set(opt).from(element).save();

			 
		});

 
 
	});
	</script>
<style>
@font-face {
font-family: "bangl";
src: url("../font/Nikosh-bengalifont.com/Nikosh.ttf");
}
@font-face {
font-family: "bangls";
src: url("<?php echo niva_url.'/niva/'; ?>/font/SolaimanLipi_22-02-2012.ttf");
}
p{margin:0;


}










</style>
</head>

<body style="font-family:bangl;">

<center>
   
<div style="height:mm;width:345mm;pmargin:0;display:;padding:0;font-family:bangls;" id="printarea">

<div style="height:206.9mm;">

<table style="width:100%;">
	<tr>
		<td style="width:25%;"></td>
		<td style="width:50%;text-align:center;">
		<p style="font-size:10mm;"><b>দারুল   উলুম   ইসলামিয়া   মাদরাসা</b></p>
		<p style="font-size:6mm;">বাঁকা , জীবননগর, চুয়াডাঙ্গা।</p>
			<p style="font-size:6mm;"><?php
				
										 $selectYear="SELECT * FROM $tableyear WHERE `en`='$year'";
										 $runyear=mysqli_query($con,$selectYear);
										 while($year1=mysqli_fetch_array($runyear)){
											 
											 echo $year1[$lang];
											 
										 }
										
										
										?>   ইং শিক্ষাবর্ষ</p>
			
			<p style="font-size:7mm;">		<?php
														if($type==1){
														
														echo "প্রথম সাময়িক পরিক্ষার";
														}else{
														
														if($type==2){
														 
														echo "দ্বিতীয় সাময়িক পরিক্ষার";
														}else{
														
														if($type==3){
														
														echo "তৃতীয় সাময়িক পরিক্ষার  ";
														}
														
														
														}
														
														
														}
														
														
														
														?>
  ফলাফল</p>
			<p style="font-size:7mm;">জামাতঃ<?php
									$selectcl="SELECT * FROM $tableclass WHERE `id`='$class'";
									
									 $runcl=mysqli_query($con,$selectcl);
										 while($cl=mysqli_fetch_array($runcl)){
											 
											 echo $cl[$lang];
											 
										 }
									?></p>
			
		</td>
		<td style="width:25%;">
		
		
		<div style="border:1px solid black;font-size:4mm;padding:3px 8px;margin-top:50px;">
		<h1 style="text-align:center;font-size:5mm;">বিভাগ বিন্যাস</h1>
		<table>
			<tr>
				<td>(স্টারমার্ক) মুমতায </td>
				<td>: ৮০</td>
			</tr>
			<tr>
				<td>জায়্যিদ জিদ্দান ( ১ম বিভাগ) </td>
				<td>: ৬৫</td>
			</tr>
			<tr>
				<td>জায়্যিদ  ( ২য় বিভাগ) </td>
				<td>: ৫০</td>
			</tr> 
			<tr>
				<td>মাকবুল ( ৩য় বিভাগ) </td>
				<td>: ৩৫</td>
			</tr>			
		</table>
		
		
		
		
		
		
		</div>
		
		
		
		
		</td>
		
	</tr>
</table>








<table style="border:1px solid black;border-collapse:collapse;width:100%;text-align:center;font-size:4.5mm;position:relative;">

<tr style="width:100%;padding:3px;">
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >ক্রঃ নং</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;">আইডি নং</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:16px;width:50mm;">ছাত্রের নাম</td>
<?php
		$selectscd="SELECT * FROM $tablesubbyclass WHERE `class`='$class' ";
		$runsc=mysqli_query($con,$selectscd);
		while($scd=mysqli_fetch_array($runsc)){
			
			$sid=$scd['sub-code'];
			
			
		
		
		?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<td style="border:1px solid black;border-collapse:collapse;padding:10px;" >
	














	
	<?php
	
	
	
	$b="SELECT * FROM $tablebook WHERE `id` = '$sid' ";
	$runb=mysqli_query($con,$b);
	while($boik=mysqli_fetch_array($runb)){
		
		echo  $boik[$lang];
	}
		
	?>
		</td>
		
		<?php
		
		}?>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >মোট</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >গড়</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >বিভাগ</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >প্রাপ্তস্থান</td>
</tr>








<?php

						$select114112="SELECT `Registration_number`,SUM(point) AS sum FROM $tableresult WHERE `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`  ORDER BY SUM(point) DESC";
						$ran11411112=mysqli_query($con,$select114112);
						$rowcount=mysqli_num_rows($ran11411112);


						$select11411="SELECT `Registration_number`,SUM(point) AS sum FROM $tableresult WHERE `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`  ORDER BY SUM(point) DESC LIMIT 0,13";
						$ran1141111=mysqli_query($con,$select11411);
						while($data1411=mysqli_fetch_array($ran1141111)){
						
						
						
						
						
						
					
					  $as1=$data1411['Registration_number'];
		
						
						
						
						
						

					$selectst1245="SELECT * FROM $tablestinfo WHERE `Class`='$class' AND `year` ='$year' AND `id`='$as1' ";
					$runst121=mysqli_query($con,$selectst1245);
					while($st12=mysqli_fetch_array($runst121)){
					$name12=$st12[$lang];

					$rol12=$st12['id'];
?>













<tr style="width:100%;">
	<td style="border:1px solid black;border-collapse:collapse;" >
	
	<?php
		
		
	
	$b1="SELECT * FROM `number` WHERE `en`='$x' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
		
	}
		$x++;
	
	
	
		?>
	
	
	</td>
	<td style="border:1px solid black;border-collapse:collapse;"><?php
	$b1="SELECT * FROM `number` WHERE `en`='$as1' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){

		echo  $boik1[$lang];
		
	}
	?></td>
	<td style="border:1px solid black;border-collapse:collapse;text-align:left;"><?php
	
		echo  $name12;
		
	
	?></td>
	
	
	
	
			<?php
		$selectscd="SELECT * FROM $tablesubbyclass WHERE `class`='$class'  ";
		$runsc=mysqli_query($con,$selectscd);
		while($scd=mysqli_fetch_array($runsc)){
			
			$sid=$scd['sub-code'];
		$b12="SELECT * FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' AND `sub-code`='$sid'";
			
			
			$runb12=mysqli_query($con,$b12);
			
			$count=mysqli_num_rows($runb12);
			
			if($count==1){
			while($boik12=mysqli_fetch_array($runb12)){
		
			$point=	 $boik12['point'];
	
	
	
		
	
	
	
		
				?>
	
	
			<td style="border:1px solid black;border-collapse:collapse;"><?php
		
			$b1="SELECT * FROM `number` WHERE `en`='$point' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
			?></td>
		
				<?php
			}
			}else{
				
				echo "<td style='border:1px solid black;border-collapse:collapse;'>"."-"."</td>";
				
			}
		
		
		
				}?>
	
	
	
	
		
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php
						$select11="SELECT SUM(point) AS sum FROM $tableresult WHERE `Registration_number`='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`";
						$ran11=mysqli_query($con,$select11);
						while($data18=mysqli_fetch_array($ran11)){
						
						$tt8=$data18['sum'];
						
						$b1="SELECT * FROM `number` WHERE `en`='$tt8' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
	
						
						}
						
						
						?></td>
	
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php	
	$selectavg="SELECT AVG(point) AS sum FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class`='$class' AND `type`='$type'";
						$ranavg=mysqli_query($con,$selectavg);
						while($data2=mysqli_fetch_array($ranavg)){
						
						$data2avg=$data2['sum'];
						
						 $left=intval($data2avg);
						 $desimal=$data2avg-$left;
						 $desimal1=round($desimal,2);
							$desimal2=substr( $desimal1,2);
						
						if($desimal2==false){
							
							$b1="SELECT * FROM `number` WHERE `en`='$left' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
	
						
						
							
							
							
						}else{
							
							
						
						
						
						
						
										
							$b1="SELECT * FROM `number` WHERE `en`='$left' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		$g1=$boik1[$lang];
		
		
		
		
		
								
							$bg="SELECT * FROM `number` WHERE `en`='$desimal2' ";
	$runbg=mysqli_query($con,$bg);
	while($boikg=mysqli_fetch_array($runbg)){
		
		$g2=$boikg[$lang];
		
		
		
		echo $g1.".".$g2;
		
		
		
		
	}
		
		
	}
						
						
						
						
						
						
						
						
							
							
							
							
						}
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						}?>
						
						</td>
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php
	
	$b1278="SELECT * FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type'   AND  `point`<'35'  ";
			
			
			$runb1278=mysqli_query($con,$b1278);
			
		 $count78=mysqli_num_rows($runb1278);
			
			
			if($count78>1){
				
				
				echo "রাসিব";
				
			}else{
			
			
			
						
						$selectavg="SELECT AVG(point) AS sum FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class`='$class' AND `type`='$type'";
						$ranavg=mysqli_query($con,$selectavg);
						while($data2=mysqli_fetch_array($ranavg)){
						
						$data2avg=$data2['sum'];
						
						}
						
						
	
	
	
	
	
	if($data2avg>79.99 && $data2avg<=100){
						echo "মুমতাজ";
						
						}else{
						
						if($data2avg>=80 && $data2avg<=100){
						echo "মুমতাজ";
						
					}else{
						if($data2avg>64.99 && $data2avg<80){
						echo "জাঃজিঃ";
						
						}else{
						
						
						if($data2avg>49.99 && $data2avg<65){
						echo "জায়্যিদ";
						
						}else{
						
						
						if($data2avg>35.99 && $data2avg<50){
						echo "মাকবুল";
						
						}else{
						
						
						echo "রাসিব";
						
						}
						
						
					}
						
						
						
					}
						
						
						}
						
						}
						
						
						
						
			}
						
						
	?></td>
	
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" >
	
	<?php
	
	
	
	
	
	
	
	
	
	
	
	
	
	$b1="SELECT * FROM `tomo` WHERE `id` ='$auto' ";
	$runb1=mysqli_query($con,$b1);
	$gon=mysqli_num_rows($runb1);
	if($gon==1){
	
	
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
		
	}
	
	}else{
		
		
		$b12="SELECT * FROM `number` WHERE `en`='$auto' ";
		
			
	while($boik1=mysqli_fetch_array($runb12)){
		
		echo  $boik1[$lang]."তম";
		
		
	}
		
		
		
		
		
	}
		$auto++;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</td>
</tr>









<?php









					}
					}



?>



















 <!--<img src="https://www.bakamadrasha.com/com/background.png" style="height:300px;width:300px;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);opacity:.2;"  />

-->





</table>







<div style="width:100%;border:none;margin:20px 10px;" class="hidet">
	
		
		<div style="width:30%;float:right;">
		
		<hr style="width:50%;float:left;display:block;"/>
		<span style="width:50%;float:left;display:block;margin:5px;">মুহতামিমের স্বাক্ষর</span>
		</div>
	<div style="width:30%;float:left;">
		
		<hr style="width:50%;float:right;display:block;"/>
		<span style="width:50%;float:right;display:block;margin:5px;">নাযিমে তালিমাতের স্বাক্ষর </span>
		</div>
</div>
</div>

<?php

if($rowcount>13){
?>





<div style="height:206.9mm;">

<table style="border:1px solid black;border-collapse:collapse;width:100%;text-align:center;font-size:4.5mm;">

<tr style="width:100%;padding:3px;">
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >ক্রঃ নং</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;">আইডি নং</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:16px;width:50mm;">ছাত্রের নাম</td>
<?php
		$selectscd="SELECT * FROM `sub_by_class` WHERE `class`='$class' ";
		$runsc=mysqli_query($con,$selectscd);
		while($scd=mysqli_fetch_array($runsc)){
			
			$sid=$scd['sub-code'];
			
			
		
		
		?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<td style="border:1px solid black;border-collapse:collapse;padding:10px;" >
	














	
	<?php
	
	
	
	$b="SELECT * FROM $tablebook WHERE `id` = '$sid' ";
	$runb=mysqli_query($con,$b);
	while($boik=mysqli_fetch_array($runb)){
		
		echo  $boik[$lang];
	}
		
	?>
		</td>
		
		<?php
		
		}?>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >মোট</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >গড়</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >বিভাগ</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >প্রাপ্তস্থান</td>
</tr>








<?php




						$select11411="SELECT `Registration_number`,SUM(point) AS sum FROM $tableresult WHERE `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`  ORDER BY SUM(point) DESC LIMIT 13,24";
						$ran1141111=mysqli_query($con,$select11411);
						
						while($data1411=mysqli_fetch_array($ran1141111)){
						
						
						
						
						
						
					
					  $as1=$data1411['Registration_number'];
		
						
						
						
						
						

					$selectst1245="SELECT * FROM $tablestinfo WHERE `Class`='$class' AND `year` ='$year' AND `id`='$as1' ";
					$runst121=mysqli_query($con,$selectst1245);
					while($st12=mysqli_fetch_array($runst121)){
					$name12=$st12[$lang];

					$rol12=$st12['Roll'];
?>













<tr style="width:100%;">
	<td style="border:1px solid black;border-collapse:collapse;" >
	
	<?php
		
		
	
	$b1="SELECT * FROM `number` WHERE `en`='$x' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
		
	}
		$x++;
	
	
	
		?>
	
	
	</td>
	<td style="border:1px solid black;border-collapse:collapse;"><?php
	$b1="SELECT * FROM `number` WHERE `en`='$as1' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
	
		echo  $boik1[$lang];
		
	}
	?></td>
	<td style="border:1px solid black;border-collapse:collapse;text-align:left;"><?php
	
		echo  $name12;
		
	
	?></td>
	
	
	
	
			<?php
		$selectscd="SELECT * FROM `sub_by_class` WHERE `class`='$class'  ";
		$runsc=mysqli_query($con,$selectscd);
		while($scd=mysqli_fetch_array($runsc)){
			
			$sid=$scd['sub-code'];
		$b12="SELECT * FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' AND `sub-code`='$sid'";
			
			
			$runb12=mysqli_query($con,$b12);
			
			$count=mysqli_num_rows($runb12);
			
			if($count==1){
			while($boik12=mysqli_fetch_array($runb12)){
		
			$point=	 $boik12['point'];
	
	
	
		
	
	
	
		
				?>
	
	
			<td style="border:1px solid black;border-collapse:collapse;"><?php
		
			$b1="SELECT * FROM `number` WHERE `en`='$point' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
			?></td>
		
				<?php
			}
			}else{
				
				echo "<td style='border:1px solid black;border-collapse:collapse;'>"."-"."</td>";
				
			}
		
		
		
				}?>
	
	
	
	
		
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php
						$select11="SELECT SUM(point) AS sum FROM $tableresult WHERE `Registration_number`='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`";
						$ran11=mysqli_query($con,$select11);
						while($data18=mysqli_fetch_array($ran11)){
						
						$tt8=$data18['sum'];
						
						$b1="SELECT * FROM `number` WHERE `en`='$tt8' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
	
						
						}
						
						
						?></td>
	
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php	
	$selectavg="SELECT AVG(point) AS sum FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class`='$class' AND `type`='$type'";
						$ranavg=mysqli_query($con,$selectavg);
						while($data2=mysqli_fetch_array($ranavg)){
						
						$data2avg=$data2['sum'];
						
						 $left=intval($data2avg);
						 $desimal=$data2avg-$left;
						 $desimal1=round($desimal,2);
							$desimal2=substr( $desimal1,2);
						
						if($desimal2==false){
							
							$b1="SELECT * FROM `number` WHERE `en`='$left' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
	
						
						
							
							
							
						}else{
							
							
						
						
						
						
						
										
							$b1="SELECT * FROM `number` WHERE `en`='$left' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		$g1=$boik1[$lang];
		
		
		
		
		
								
							$bg="SELECT * FROM `number` WHERE `en`='$desimal2' ";
	$runbg=mysqli_query($con,$bg);
	while($boikg=mysqli_fetch_array($runbg)){
		
		$g2=$boikg[$lang];
		
		
		
		echo $g1.".".$g2;
		
		
		
		
	}
		
		
	}
						
						
						
						
						
						
						
						
							
							
							
							
						}
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						}?>
						
						</td>
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php
	
	$b1278="SELECT * FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type'   AND  `point`<'35'  ";
			
			
			$runb1278=mysqli_query($con,$b1278);
			
		 $count78=mysqli_num_rows($runb1278);
			
			
			if($count78>1){
				
				
				echo "রাসিব";
				
			}else{
			
			
			
						
						$selectavg="SELECT AVG(point) AS sum FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class`='$class' AND `type`='$type'";
						$ranavg=mysqli_query($con,$selectavg);
						while($data2=mysqli_fetch_array($ranavg)){
						
						$data2avg=$data2['sum'];
						
						}
						
						
	
	
	
	
	
	if($data2avg>79.999 && $data2avg<=100){
						echo "মুমতাজ";
						
						}else{
						
						if($data2avg>=80 && $data2avg<=100){
						echo "মুমতাজ";
						
					}else{
						if($data2avg>64.99 && $data2avg<80){
						echo "জাঃজিঃ ";
						
						}else{
						
						
						if($data2avg>49.99 && $data2avg<65){
						echo "জায়্যিদ";
						
						}else{
						
						
						if($data2avg>35.99 && $data2avg<50){
						echo "মাকবুল";
						
						}else{
						
						
						echo "রাসিব";
						
						}
						
						
					}
						
						
						
					}
						
						
						}
						
						}
						
						
						
						
			}
						
						
	?></td>
	
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" >
	
	<?php
	
	
	
	
	
	
	
	
	
	
	
	
	
	$b1="SELECT * FROM `tomo` WHERE `id` ='$auto' ";
	$runb1=mysqli_query($con,$b1);
	$gon=mysqli_num_rows($runb1);
	if($gon==1){
	
	
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
		
	}
	
	}else{
		
		
		$b12="SELECT * FROM `number` WHERE `en`='$auto' ";
		
			
	while($boik1=mysqli_fetch_array($runb12)){
		
		echo  $boik1[$lang]."তম";
		
		
	}
		
		
		
		
		
	}
		$auto++;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</td>
</tr>









<?php









					}
					}



?>
























</table>
</div>


<?php

if($rowcount>37){
?>




<div style="height:206.9mm;">


<table style="border:1px solid black;border-collapse:collapse;width:100%;text-align:center;font-size:4.5mm;">

<tr style="width:100%;padding:3px;">
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >ক্রঃ নং</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;">আইডি নং</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:16px;width:50mm;">ছাত্রের নাম</td>
<?php
		$selectscd="SELECT * FROM `sub_by_class` WHERE `class`='$class' ";
		$runsc=mysqli_query($con,$selectscd);
		while($scd=mysqli_fetch_array($runsc)){
			
			$sid=$scd['sub-code'];
			
			
		
		
		?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<td style="border:1px solid black;border-collapse:collapse;padding:10px;" >
	














	
	<?php
	
	
	
	$b="SELECT * FROM $tablebook WHERE `id` = '$sid' ";
	$runb=mysqli_query($con,$b);
	while($boik=mysqli_fetch_array($runb)){
		
		echo  $boik[$lang];
	}
		
	?>
		</td>
		
		<?php
		
		}?>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >মোট</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >গড়</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >বিভাগ</td>
	<td style="border:1px solid black;border-collapse:collapse;padding:6px;" >প্রাপ্তস্থান</td>
</tr>








<?php




						$select11411="SELECT `Registration_number`,SUM(point) AS sum FROM $tableresult WHERE `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`  ORDER BY SUM(point) DESC LIMIT 37,24";
						$ran1141111=mysqli_query($con,$select11411);
						$rowcount=mysqli_num_rows($ran1141111);
						while($data1411=mysqli_fetch_array($ran1141111)){
						
						
						
						
						
						
					
					  $as1=$data1411['Registration_number'];
		
						
						
						
						
						

					$selectst1245="SELECT * FROM $tablestinfo WHERE `Class`='$class' AND `year` ='$year' AND `id`='$as1' ";
					$runst121=mysqli_query($con,$selectst1245);
					while($st12=mysqli_fetch_array($runst121)){
					$name12=$st12[$lang];

					$rol12=$st12['Roll'];
?>













<tr style="width:100%;">
	<td style="border:1px solid black;border-collapse:collapse;" >
	
	<?php
		
		
	
	$b1="SELECT * FROM `number` WHERE `en`='$x' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
		
	}
		$x++;
	
	
	
		?>
	
	
	</td>
	<td style="border:1px solid black;border-collapse:collapse;"><?php
	$b1="SELECT * FROM `number` WHERE `en`='$as1' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
	
		echo  $boik1[$lang];
		
	}
	?></td>
	<td style="border:1px solid black;border-collapse:collapse;text-align:left;"><?php
	
		echo  $name12;
		
	
	?></td>
	
	
	
	
			<?php
		$selectscd="SELECT * FROM `sub_by_class` WHERE `class`='$class'  ";
		$runsc=mysqli_query($con,$selectscd);
		while($scd=mysqli_fetch_array($runsc)){
			
			$sid=$scd['sub-code'];
		$b12="SELECT * FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' AND `sub-code`='$sid'";
			
			
			$runb12=mysqli_query($con,$b12);
			
			$count=mysqli_num_rows($runb12);
			
			if($count==1){
			while($boik12=mysqli_fetch_array($runb12)){
		
			$point=	 $boik12['point'];
	
	
	
		
	
	
	
		
				?>
	
	
			<td style="border:1px solid black;border-collapse:collapse;"><?php
		
			$b1="SELECT * FROM `number` WHERE `en`='$point' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
			?></td>
		
				<?php
			}
			}else{
				
				echo "<td style='border:1px solid black;border-collapse:collapse;'>"."-"."</td>";
				
			}
		
		
		
				}?>
	
	
	
	
		
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php
						$select11="SELECT SUM(point) AS sum FROM $tableresult WHERE `Registration_number`='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type' GROUP BY `Registration_number`";
						$ran11=mysqli_query($con,$select11);
						while($data18=mysqli_fetch_array($ran11)){
						
						$tt8=$data18['sum'];
						
						$b1="SELECT * FROM `number` WHERE `en`='$tt8' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
	
						
						}
						
						
						?></td>
	
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php	
	$selectavg="SELECT AVG(point) AS sum FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class`='$class' AND `type`='$type'";
						$ranavg=mysqli_query($con,$selectavg);
						while($data2=mysqli_fetch_array($ranavg)){
						
						$data2avg=$data2['sum'];
						
						 $left=intval($data2avg);
						 $desimal=$data2avg-$left;
						 $desimal1=round($desimal,2);
							$desimal2=substr( $desimal1,2);
						
						if($desimal2==false){
							
							$b1="SELECT * FROM `number` WHERE `en`='$left' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
	}
	
						
						
							
							
							
						}else{
							
							
						
						
						
						
						
										
							$b1="SELECT * FROM `number` WHERE `en`='$left' ";
	$runb1=mysqli_query($con,$b1);
	while($boik1=mysqli_fetch_array($runb1)){
		
		$g1=$boik1[$lang];
		
		
		
		
		
								
							$bg="SELECT * FROM `number` WHERE `en`='$desimal2' ";
	$runbg=mysqli_query($con,$bg);
	while($boikg=mysqli_fetch_array($runbg)){
		
		$g2=$boikg[$lang];
		
		
		
		echo $g1.".".$g2;
		
		
		
		
	}
		
		
	}
						
						
						
						
						
						
						
						
							
							
							
							
						}
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						}?>
						
						</td>
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" ><?php
	
	$b1278="SELECT * FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class` ='$class' AND `type` ='$type'   AND  `point`<'35'  ";
			
			
			$runb1278=mysqli_query($con,$b1278);
			
		 $count78=mysqli_num_rows($runb1278);
			
			
			if($count78>1){
				
				
				echo "রাসিব";
				
			}else{
			
			
			
						
						$selectavg="SELECT AVG(point) AS sum FROM $tableresult WHERE `Registration_number` ='$as1' AND `year` = '$year' AND `class`='$class' AND `type`='$type'";
						$ranavg=mysqli_query($con,$selectavg);
						while($data2=mysqli_fetch_array($ranavg)){
						
						$data2avg=$data2['sum'];
						
						}
						
						
	
	
	
	
	
	if($data2avg>79.99 && $data2avg<=100){
						echo "মুমতাজ";
						
						}else{
						
						if($data2avg>=80 && $data2avg<=100){
						echo "মুমতাজ";
						
					}else{
						if($data2avg>64.9999 && $data2avg<80){
						echo "জাঃজিঃ ";
						
						}else{
						
						
						if($data2avg>49.999 && $data2avg<65){
						echo "জায়্যিদ";
						
						}else{
						
						
						if($data2avg>35.999 && $data2avg<50){
						echo "মাকবুল";
						
						}else{
						
						
						echo "রাসিব";
						
						}
						
						
					}
						
						
						
					}
						
						
						}
						
						}
						
						
						
						
			}
						
						
	?></td>
	
	
	
	
	<td style="border:1px solid black;border-collapse:collapse;" >
	
	<?php
	
	
	
	
	
	
	
	
	
	
	
	
	
	$b1="SELECT * FROM `tomo` WHERE `id` ='$auto' ";
	$runb1=mysqli_query($con,$b1);
	$gon=mysqli_num_rows($runb1);
	if($gon==1){
	
	
	while($boik1=mysqli_fetch_array($runb1)){
		
		echo  $boik1[$lang];
		
	}
	
	}else{
		
		
		$b12="SELECT * FROM `number` WHERE `en`='$auto' ";
		
			
	while($boik1=mysqli_fetch_array($runb12)){
		
		echo  $boik1[$lang]."তম";
		
		
	}
		
		
		
		
		
	}
		$auto++;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</td>
</tr>









<?php









					}
					}



?>
























</table>

</div>




<?php
}


?>






</div>

</center>



<div class="donwdiv" style="width:400px;height:270px;background:#dddddd63;display:none;margin:100px auto;border-radius:10px;box-shadow: 4px 6px 10px #d3cbcb;">
	<img src="https://www.bakamadrasha.com/com/background.png" style="width:51mm;height:51mm;border-radius:50%;position:relative;top:-25%;left:25%;border:2px solid #dddddd63;">
		<button class="btn_print" style="width:70%;height:80px;border-radius:10px;background:green;color:#fff;border:none;display:block;margin:0 auto;">DOWNLOAD PDF</button>
	</div>
	

	
	
<script type="text/javascript">



 function my() {
    
    
  
    var divToPrint = document.getElementById('printarea');
    var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:;' +
        'border-collapse:collapse;'+
        'padding;0.5em;' +
        '}' +
        'p{margin:0;}'+
        '</style>';
    htmlToPrint += divToPrint.outerHTML;
    newWin = window.open("");
    
    newWin.document.write(htmlToPrint);
    newWin.print();
    newWin.close();
    
    
    
    
}


</script>


<?php
}

?>

</body>
</html>
