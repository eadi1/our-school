<?php

require_once('../../../../wp-config.php');


$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

$year="2022/23";
?>