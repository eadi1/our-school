
<!DOCTYPE HTML>
<html lang="en-US">
<head>
 <meta name="description" content="Baka madrasha">
  <meta name="keywords" content="baka,baka madrasha result,baka madrasha vorti,banka madrasha addmission">
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<meta charset="UTF-8">
	
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style>
    @font-face {
font-family: "bangls";
src: url("https://www.bakamadrasha.com/font/SolaimanLipi_22-02-2012.ttf");
}
    
    
    
   form{
        font-family:bangls;
        
        
    }
    
    
    
    
    
    
</style>

</head>
<body >
	
	
	
		<form action="core_addmission.php" enctype="multipart/form-data" method="post">
	
	<div id="" style="width:95%;
  
    margin-top: 100px;
    background: #ffff;
    display: block;
    margin-left: auto;
    margin-right: auto;
    box-shadow: 8px 12px 17px 3px rgb(128 134 139 / 43%);">
	<div style="width:206px;height:;border-radius:50%;border:2px solid blue;margin-left:auto;display:block;margin-right:auto;position:relative;top:-100px;background:#fff;" id="partimg" >
	<label for="connect"><img id="output" style="height:199px;width:200px;border-radius:50%;"src="https://www.bakamadrasha.com/UP.png" alt="login" /></label>
		<!--<input name="spic" type="file" />-->
<input style="display:none;" type="file" id="connect"  accept="image/*"   name="spic"onchange="loadFile(event)" required />
		
		
		
		
		
		
	</div>
	
	
	
	
	
	
	<div class="container">

	<h5>ছাত্রের তথ্য</h5>
	 <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputname">নাম</label>
      <input type="text" class="form-control" id="inputname" name="bn" >
    </div>
    <div class="form-group col-md-4">
      <input type="hidden" name="wclass" value="9" />
         <input type="hidden" name="phone" value="01883445538" />
       <input type="hidden" name="text" value="bakamadr_63c698b451777" />
		<label for="inputdob">জন্ম তারিখ </label>
      <input type="text" class="form-control" id="inputdob" name="dob" >
      </select> 
    </div>
    <div class="form-group col-md-4">
      <label for="inputage">বয়স</label>
      <input type="text" class="form-control" id="inputage" name="age">
    </div>
  </div>

	
	
	
	
	
	
	<div class="form-row">
    <div class="form-group col-md-9">
      <label for="inputfn">পিতার নাম</label>
      <input type="text" class="form-control" id="inputfn" name="Fn" >
    </div>
    <div class="form-group col-md-3">
      <label for="inputfp">পেশা </label>
      <input type="text" class="form-control" id="inputfp" name="Fp">
    </div>
	</div>
  
	<div class="form-row">
    <div class="form-group col-md-9">
     <label for="inputmn">মাতার নাম </label>
      <input type="text" class="form-control" id="inputmn" name="Mn" >
    </div>
    <div class="form-group col-md-3">
      <label for="inputmp">পেশা</label>
      <input type="text" class="form-control" id="inputmp" name="Mp" >
    </div>
	</div>
  
  
  <h5>বর্তমান ঠিকানা </h5>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="inputpd">জেলা </label>
      <input type="text" class="form-control" id="pz" name="pz" >
    </div>
    <div class="form-group col-md-3">
      <label for="inputps">উপজেলা</label>
      <input type="text" class="form-control" id="pu" name="pu">
    </div>
	
    <div class="form-group col-md-3">
      <label for="inputpp">পোস্ট অফিস </label>
      <input type="text" class="form-control" id="pd" name="pd" >
    </div>
    <div class="form-group col-md-3">
      <label for="inputpv">গ্রাম</label>
      <input type="text" class="form-control" id="pv" name="pv">
    </div>
	</div>
	<div class="form-check">
  <input class="form-check-input" onchange="ck()" type="checkbox" value="" id="check">
  <label class="form-check-label" for="check">
    যদি একই হয় 
  </label>
</div>
  <h5>স্থায়ী ঠিকানা </h5>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label >জেলা </label>
      <input type="text" class="form-control" id="sz" name="sz" >
    </div>                                   
	<div class="form-group col-md-3">        
      <label >উপজেলা</label>                 
	  <input type="text" class="form-control" id="su"  name="su"  >
    </div>                                 
	                                       
    <div class="form-group col-md-3">      
      <label >পোস্ট অফিস</label>          
      <input type="text" class="form-control" id="sd" name="sd"  >
    </div>                                   
    <div class="form-group col-md-3">
      <label >গ্রাম</label>                
      <input type="text" class="form-control" id="sv" name="sv"  >
    </div>
	</div>
  
  
  
  
  
  <h5>অভিভাবকের তথ্য </h5>
   <div class="form-row">
    <div class="form-group col-md-3">
      <label >নাম</label>
      <input type="text" class="form-control" name="Gn"id="inputCity" >
    </div>
    <div class="form-group col-md-3">
       
		<label >সম্পর্ক </label>
      <input type="text" class="form-control" name="Grel" id="inputCity">
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="inputZip">ফোন নাম্বার</label>
      <input type="text" class="form-control" 
name="Gph"id="inputZip" >
    </div>
    <div class="form-group col-md-3">
      <label for="inputZip"> ঠিকানা </label>
      <input type="text" class="form-control" 
 name="Gpadd" id="inputZip" >
    </div>
  </div>

	
	
	
	
  
  
 
  
  
  <h5>পূর্বের শিক্ষা গ্রহন সম্পর্কে </h5>
   <div class="form-row">
    <div class="form-group col-md-3">
      <label >পূর্বের শিক্ষা প্রতিষ্ঠানের নাম</label>
      <input type="text" class="form-control"  name="pin"id="inputCity" />
    </div>
    <div class="form-group col-md-3">
      
		<label >পাশের সাল </label>
      <input type="text" class="form-control" name="py"id="inputCity" >
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="inputZip">শ্রেনী </label>
      <input type="text" class="form-control" name="pclass"id="inputZip" >
    </div>
  

     <div class="form-group col-md-3">
      <label for="inputZip">ফলাফল </label>
      <input type="text" class="form-control" name="lg"id="inputZip" >
      <input type="hidden" value="....."  name="bno" required />
      <input id="fnid" type="hidden" value="......" name="Gnid" required />
    </div>
  </div>
  <button type="submit" class="btn btn-primary">আগীয়ে যান
  </button>

	
	</div>
	
	
	
	
	
	</div>
	</form>
	
	
<script>


  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };
  
  
  
  
  function ck(){
      var check=document.getElementById("check").checked;
      
      if(check=true){
          
          document.getElementById("sz").value=document.getElementById("pz").value;
          document.getElementById("su").value=document.getElementById("pu").value;
          document.getElementById("sd").value=document.getElementById("pd").value;
          document.getElementById("sv").value=document.getElementById("pv").value;
          
      }else{
          
          
          
      }
      
  };
</script>
	
	
</body>
</html>